
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'harshmohan813',
  applicationName: 'beta',
  appUid: 'q8rl6SRMHdnYdjHVlQ',
  orgUid: '42b93afe-53d2-466b-8803-eb998db0b3bf',
  deploymentUid: '0bb3090c-6f66-40ab-9b90-6a184ebe1a9d',
  serviceName: 'beta',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'beta-dev-createPost', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createPost, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}
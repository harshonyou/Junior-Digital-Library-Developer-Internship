
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'harshmohan813',
  applicationName: 'database-app',
  appUid: 'LhXyd403x7M7rxkg7M',
  orgUid: '42b93afe-53d2-466b-8803-eb998db0b3bf',
  deploymentUid: '1c4e0c3d-c1c8-4ebd-b04e-e8c70fbadadd',
  serviceName: 'blogPosts',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'blogPosts-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}